Team Name: UNUS
Group Members:
 - Marshall Steele
 - Marianne Dery
 - Vivienne Cruz
 - Kevin Wang
 - Yvan Cubahiro
 (Student numbers can be found in deliverable #1 text file)

Project Name: myRide
Project Description:
myRide is a mobile application perfect for anyone in Ottawa who travels without a car. 
It compares a variety of ride services based on various filters such as prices and 
traveling distances to fit everyone’s preferences.
